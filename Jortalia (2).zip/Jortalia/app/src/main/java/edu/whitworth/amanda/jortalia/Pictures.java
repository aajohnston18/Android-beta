package edu.whitworth.amanda.jortalia;

import android.accounts.*;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class Pictures extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pictures);

        //How do I change the image id from here? Can I even do that?

        ImageView blue = (ImageView) findViewById(R.id.blue);
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent blue = new Intent(Pictures.this, Edit.class);
                //int change = R.mipmap.defaultplayer;
                // Edit.class.getDeclaredField(Profile_Pic);
                startActivity(blue);
            }
        });

        ImageView pink = (ImageView) findViewById(R.id.pink);
        pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pink = new Intent(Pictures.this, Edit.class);
                //int change = R.mipmap.playerp;
                // Edit.class.getDeclaredField(Profile_Pic);
                startActivity(pink);
            }
        });

        ImageView yellow = (ImageView) findViewById(R.id.yellow);
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent yellow = new Intent(Pictures.this, Edit.class);
                //int change = R.mipmap.playery;
                // Edit.class.getDeclaredField(Profile_Pic);
                startActivity(yellow);
            }
        });

    }
}
