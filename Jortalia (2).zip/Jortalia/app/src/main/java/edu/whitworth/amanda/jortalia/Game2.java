package edu.whitworth.amanda.jortalia;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.Random;

public class Game2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game2);

        //Going to work on the card arrays over the weekend (At least it stopped crashing!)

        final int cards[] = {R.mipmap.emperorb, R.mipmap.emperorblue, R.mipmap.emperorp, R.mipmap.emperorred, R.mipmap.kingb, R.mipmap.kingblue, R.mipmap.kingp,
        R.mipmap.kingred, R.mipmap.knightb, R.mipmap.knightblue, R.mipmap.knightp, R.mipmap.knightred, R.mipmap.merchantb, R.mipmap.merchantblue,
        R.mipmap.merchantp, R.mipmap.merchantred, R.mipmap.nobleb, R.mipmap.nobleblue, R.mipmap.noblep, R.mipmap.noblered, R.mipmap.peasantb,
        R.mipmap.peasantblue, R.mipmap.peasantp, R.mipmap.peasantred, R.mipmap.princessb, R.mipmap.princessblue, R.mipmap.princessp,
        R.mipmap.princessred, R.mipmap.queenb, R.mipmap.queenblue, R.mipmap.queenp, R.mipmap.queenred};

        ImageView home4 = (ImageView) findViewById(R.id.Game_Listing);
        home4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent home4 = new Intent(Game2.this, Home.class);
                startActivity(home4);
            }
        });

        ImageView deck = (ImageView) findViewById(R.id.New_Card);
        deck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random rand = new Random();
                int n = rand.nextInt(32);
                ImageView mycard = (ImageView) findViewById(R.id.Player_Card);
                mycard.setImageResource(cards[n]);
            }
        });

    }
}
